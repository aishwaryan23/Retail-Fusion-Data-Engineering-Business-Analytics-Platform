# Databricks notebook source
# DBTITLE 1,Title
# MAGIC %md
# MAGIC # Calendar Dimension Table
# MAGIC
# MAGIC Creates a calendar dimension table `retail_fusion.retail_gold.dim_calendar` with standard date attributes (year, quarter, month, week, day, etc.) from a user-specified start and end date.

# COMMAND ----------

# DBTITLE 1,Date Range Parameters
dbutils.widgets.text("start_date", "2020-01-01", "Start Date (YYYY-MM-DD)")
dbutils.widgets.text("end_date", "2030-12-31", "End Date (YYYY-MM-DD)")

# COMMAND ----------

# DBTITLE 1,Create dim_calendar Table
start_date = dbutils.widgets.get("start_date")
end_date = dbutils.widgets.get("end_date")

spark.sql(f"""
CREATE OR REPLACE TABLE retail_fusion.retail_gold.dim_calendar AS
WITH date_range AS (
    SELECT explode(sequence(to_date('{start_date}'), to_date('{end_date}'), interval 1 day)) AS date
)
SELECT
    date                                                  AS date,
    year(date)                                            AS year,
    quarter(date)                                         AS quarter,
    month(date)                                           AS month_number,
    date_format(date, 'MMMM')                             AS month_name,
    date_format(date, 'MMM')                              AS month_short_name,
    weekofyear(date)                                      AS week_of_year,
    dayofyear(date)                                       AS day_of_year,
    dayofmonth(date)                                      AS day_of_month,
    dayofweek(date)                                       AS day_of_week,
    date_format(date, 'EEEE')                             AS day_name,
    date_format(date, 'EEE')                              AS day_short_name,
    CASE WHEN dayofweek(date) IN (1, 7) THEN true ELSE false END AS is_weekend,
    CASE WHEN dayofmonth(date) = 1 THEN true ELSE false END      AS is_month_start,
    CASE WHEN date = last_day(date) THEN true ELSE false END     AS is_month_end,
    CASE WHEN month(date) IN (1, 4, 7, 10) AND dayofmonth(date) = 1 THEN true ELSE false END AS is_quarter_start,
    CASE WHEN date = last_day(add_months(date - dayofmonth(date) + 1, 3 - ((month(date) - 1) % 3))) THEN true ELSE false END AS is_quarter_end,
    CASE WHEN month(date) = 1 AND dayofmonth(date) = 1 THEN true ELSE false END AS is_year_start,
    CASE WHEN month(date) = 12 AND dayofmonth(date) = 31 THEN true ELSE false END AS is_year_end
FROM date_range
ORDER BY date
""")

spark.sql("ALTER TABLE retail_fusion.retail_gold.dim_calendar ALTER COLUMN date SET NOT NULL")

spark.sql("ALTER TABLE retail_fusion.retail_gold.dim_calendar ADD CONSTRAINT dim_calendar_pk PRIMARY KEY (date)")

spark.sql("OPTIMIZE retail_fusion.retail_gold.dim_calendar")

display(spark.table("retail_fusion.retail_gold.dim_calendar"))