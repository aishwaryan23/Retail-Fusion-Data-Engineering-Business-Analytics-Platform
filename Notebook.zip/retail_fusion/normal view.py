# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE VIEW retail_fusion.retail_semantic.retail_dashboard AS
# MAGIC
# MAGIC SELECT
# MAGIC     `Transaction Date`,
# MAGIC     `Year`,
# MAGIC     `Quarter`,
# MAGIC     `Month Name`,
# MAGIC     `Product Category`,
# MAGIC     `Product Brand`,
# MAGIC     `Payment Mode`,
# MAGIC     `Sales Channel`,
# MAGIC     `Stage Name`,
# MAGIC     `Customer Type`,
# MAGIC     `Customer Name`,
# MAGIC     `Billing City`,
# MAGIC     `Billing State`,
# MAGIC     `Billing Country`,
# MAGIC     `Industry`,
# MAGIC
# MAGIC     MEASURE(`Transaction Count`) AS `Transaction Count`,
# MAGIC     MEASURE(`Total Revenue`) AS `Total Revenue`,
# MAGIC     MEASURE(`Total Quantity Sold`) AS `Total Quantity Sold`,
# MAGIC     MEASURE(`Total Discount`) AS `Total Discount`,
# MAGIC     MEASURE(`Average Transaction Value`) AS `Average Transaction Value`,
# MAGIC     MEASURE(`Unique Customers`) AS `Unique Customers`
# MAGIC
# MAGIC FROM retail_fusion.retail_semantic.retail_metrics
# MAGIC
# MAGIC GROUP BY ALL;

# COMMAND ----------

