# Databricks notebook source
# DBTITLE 1,Blob to Bronze: Transactions
# MAGIC %md
# MAGIC # Blob to Bronze: Transactions
# MAGIC
# MAGIC Ingests CSV files from the blob source volume into the `retail_fusion.blob_bronze.transactions` Delta table using Auto Loader.

# COMMAND ----------

# DBTITLE 1,Auto Loader: CSV to Bronze Delta Table
df = (spark.readStream
      .format("cloudFiles")
      .option("cloudFiles.format","csv")
      .option("cloudFiles.schemaLocation","/Volumes/retail_fusion/volumes/blob_source/_schema")
      .option("header","true")
      .option("inferSchema","true")
      .load("/Volumes/retail_fusion/volumes/blob_source/transactions_source/")
      )
from pyspark.sql.functions import col
df = (
    df
    .withColumn("quantity", col("quantity").cast("int"))
    .withColumn("selling_price", col("selling_price").cast("int"))
    .withColumn("discount_amount", col("discount_amount").cast("int"))
)
query = (df.writeStream
 .option("checkpointLocation","/Volumes/retail_fusion/volumes/blob_source/_checkpoint")
 .option("mergeSchema","true")
 .trigger(availableNow=True)
 .toTable("retail_fusion.blob_bronze.transactions"))

query .awaitTermination()

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from retail_fusion.blob_bronze.transactions

# COMMAND ----------

